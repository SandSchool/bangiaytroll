<?php
return array(
    'base' => '/PTITCNTT02/DuAn/DuAnBruh/',
    'baseURL' => 'http://localhost/PTITCNTT02/DuAn/DuAnBruh/',
    'assets' => '/PTITCNTT02/DuAn/DuAnBruh/assets',
    'db' => array(
        'host'     => 'localhost',
        'name'     => 'gaybangiay',
        'username' => 'root',
        'password' => ''
    )
);
