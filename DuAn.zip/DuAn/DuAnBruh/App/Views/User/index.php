<?php
echo  "This is index view for user";
